Proyek Automation Testing dan Clean Architecture
Selamat! Anda telah menyelesaikan pembelajaran pada Modul Automation Testing dan Clean Architecture. Sejauh ini, Anda telah:

Menuliskan automation testing dengan kultur TDD.
Menguji aplikasi mulai dari tahapan unit, integration, hingga functional.
Menerapkan Test Double seperti dummy, stub, mock, dan spy.
Mengenkapsulasi logika bisnis dari framework atau teknologi luar dengan menerapkan Clean Architecture.
Anda juga sudah mengerjakan seluruh latihan yang diberikan pada Modul Automation Testing dan Clean Architecture dengan baik.

Untuk menuju ke modul selanjutnya, ada tugas yang harus dikerjakan yakni membuat proyek Forum API sesuai kriteria yang kami tentukan. Tim Reviewer akan memeriksa pekerjaan Anda dan memberikan review pada proyek yang Anda buat.


Studi Kasus Forum API
Garuda Game (perusahaan fiktif) merupakan sebuah perusahaan paling sukses dalam menjalankan bisnis di bidang online game. Perusahaan tersebut memiliki ratusan game yang dimainkan oleh jutaan pengguna di seluruh dunia. Salah satu kunci keberhasilan Garuda Game adalah dekat dengan para pemainnya. Mereka berhasil membangun komunitas yang aktif.

Untuk menjaga kualitas layanan terhadap komunitas, Garuda Game berinisiatif untuk membangun aplikasi diskusi atau forum untuk para pemain. Dengan hadirnya platform diskusi yang resmi, para pemain akan sangat terbantu dan merasa nyaman untuk berdiskusi perihal game yang mereka mainkan. Aplikasi forum akan tersedia di platform web ataupun mobile native.

Garuda Game ingin aplikasi forum didesain secara matang. Seperti menerapkan automation testing, menerapkan clean architecture. Dengan begitu, aplikasi ini bisa terhindar dari bug, mudah beradaptasi pada perubahan teknologi, dan mudah untuk dikembangkan.

Untuk mencapai itu, Garuda Game menghadirkan talenta terbaik dalam membangun aplikasi forum. Salah satunya adalah Anda yang ditugaskan untuk membangun Back-End API guna mendukung fungsionalitas dari aplikasi Front-End.

Aplikasi forum dikembangkan secara bertahap dan saat ini diharapkan sudah memiliki fitur:

Registrasi Pengguna;
Login dan Logout;
Menambahkan Thread;
Melihat Thread;
Menambahkan dan Menghapus Komentar pada Thread; serta
Menambahkan dan Menghapus Balasan Komentar Thread (opsional).




Starter Project Forum API
Authentication merupakan salah satu fitur yang harus dimiliki Forum API. Namun karena pada latihan Anda sudah membangun Auth API, jadi fitur tersebut tidak akan kami jadikan sebagai syarat atau kriteria. Anda dapat menggunakan Auth API sebagai starter project atau mengunduhnya pada tautan yang sudah kami sediakan:

Forum API Starter Project
Berikut beberapa catatan yang perlu Anda ketahui mengenai starter project yang kami sediakan:

Starter Project yang kami berikan kurang lebih sama seperti proyek Auth API pada latihan modul Clean Architecture.
Starter Project Forum API sudah mencakup fitur:
Registrasi Pengguna;
Login;
Refresh Access Token; dan
Logout;
Starter Project sudah memiliki pengujian yang lengkap dan menerapkan 100% Test Coverage.
Pada starter project kami sudah sediakan berkas .env dan konfigurasi untuk melakukan pengujian database. Anda boleh menyesuaikan nilai environment variable sesuai kebutuhan Anda bila diperlukan.
Starter project bersifat opsional. Bila Anda ingin mengerjakan submission dari awal, pastikan Forum API memiliki fitur yang sudah disebutkan pada poin kedua.


Kriteria Forum API
Terdapat 6 kriteria utama yang harus Anda penuhi dalam membuat proyek Forum API.

Kriteria 1: Menambahkan Thread
API harus dapat menambahkan thread melalui route:

Method: POST
Path: /threads
Body Request:
{
    "title": string,
    "body": string
}
Response yang harus dikembalikan:

Status Code: 201
Response Body:
{
    "status": "success",
    "data": {
        "addedThread": {
            "id": "thread-h_W1Plfpj0TY7wyT2PUPX",
            "title": "sebuah thread",
            "owner": "user-DWrT3pXe1hccYkV1eIAxS"
        }
    }
}
Ketentuan:

Menambahkan thread merupakan resource yang dibatasi (restrict). Untuk mengaksesnya membutuhkan access token guna mengetahui siapa yang membuat thread.
Jika properti body request tidak lengkap atau tidak sesuai, maka:
Kembalikan dengan status code 400; serta
Berikan body response: 
status: “fail”
message: Pesan apapun selama tidak kosong.


Kriteria 2: Menambahkan Komentar pada Thread
API harus dapat menambahkan komentar pada thread melalui route:

Method: POST
Path: /threads/{threadId}/comments
Body Request:
{
    "content": string
}
Response yang harus dikembalikan:

Status Code: 201
Response Body:
{
    "status": "success",
    "data": {
        "addedComment": {
            "id": "comment-_pby2_tmXV6bcvcdev8xk",
            "content": "sebuah comment",
            "owner": "user-CrkY5iAgOdMqv36bIvys2"
        }
    }
}
Ketentuan:

Menambahkan komentar pada thread merupakan resource yang dibatasi (restrict). Untuk mengaksesnya membutuhkan access token guna mengetahui siapa yang membuat komentar.
Jika thread yang diberi komentar tidak ada atau tidak valid, maka:
Kembalikan dengan status code 404; serta
Berikan body response: 
status: “fail”
message: Pesan apapun selama tidak kosong.
Jika properti body request tidak lengkap atau tidak sesuai, maka:
Kembalikan dengan status code 400; serta
Berikan body response: 
status: “fail”
message: Pesan apapun selama tidak kosong.


Kriteria 3: Menghapus Komentar pada Thread
API harus dapat menghapus komentar pada thread melalui route:

Method: DELETE
Path: /threads/{threadId}/comments/{commentId}
Response yang harus dikembalikan:

Status Code: 200
Response Body:
{
    "status": "success"
}
Ketentuan:

Menghapus komentar pada thread merupakan resource yang dibatasi (restrict). Untuk mengaksesnya membutuhkan access token guna mengetahui siapa yang menghapus komentar.
Hanya pemilik komentar yang dapat menghapus komentar. Bila bukan pemilik komentar, maka:
Kembalikan dengan status code 403; serta
Berikan body response: 
status: “fail”
message: Pesan apapun selama tidak kosong.
Jika thread atau komentar yang hendak dihapus tidak ada atau tidak valid, maka:
Kembalikan dengan status code 404; serta
Berikan body response: 
status: “fail”
message: Pesan apapun selama tidak kosong.
Komentar dihapus secara soft delete, alias tidak benar-benar dihapus dari database. Anda bisa membuat dan memanfaatkan kolom seperti is_delete sebagai indikator apakah komentar dihapus atau tidak.


Kriteria 4: Melihat Detail Thread
API harus dapat melihat detail thread melalui route:

Method: GET
Path: /threads/{threadId}
Response yang harus dikembalikan:

Status Code: 200
Response Body:
{
    "status": "success",
    "data": {
        "thread": {
            "id": "thread-h_2FkLZhtgBKY2kh4CC02",
            "title": "sebuah thread",
            "body": "sebuah body thread",
            "date": "2021-08-08T07:19:09.775Z",
            "username": "dicoding",
            "comments": [
                {
                    "id": "comment-_pby2_tmXV6bcvcdev8xk",
                    "username": "johndoe",
                    "date": "2021-08-08T07:22:33.555Z",
                    "content": "sebuah comment"
                },
                {
                    "id": "comment-yksuCoxM2s4MMrZJO-qVD",
                    "username": "dicoding",
                    "date": "2021-08-08T07:26:21.338Z",
                    "content": "**komentar telah dihapus**"
                }
            ]
        }
    }
}
Ketentuan:

Mendapatkan detail thread merupakan resource terbuka. Sehingga tidak perlu melampirkan access token.
Jika thread yang diakses tidak ada atau tidak valid, maka:
Kembalikan dengan status code 404; serta
Berikan body response: 
status: “fail”
message: Pesan apapun selama tidak kosong.
Wajib menampilkan seluruh komentar yang terdapat pada thread tersebut sesuai dengan contoh di atas.
Komentar yang dihapus ditampilkan dengan konten **komentar telah dihapus**.
Komentar diurutkan secara ascending (dari kecil ke besar) berdasarkan waktu berkomentar.


Kriteria 5: Menerapkan Automation Testing
Proyek Forum API wajib menerapkan automation testing dengan kriteria berikut:

Unit Testing: 
Wajib menerapkan Unit Testing pada bisnis logika yang ada. Baik di Entities ataupun di Use Case.
Integration Test:
Wajib menerapkan Integration Test dalam menguji interaksi database dengan Repository.


Kriteria 6: Menerapkan Clean Architecture
Proyek Forum API wajib menerapkan Clean Architecture. Di mana source code terdiri dari 4 layer yaitu:

Entities (jika dibutuhkan)
Tempat penyimpanan data entitas bisnis utama. Jika suatu bisnis butuh mengelola struktur data yang kompleks, maka buatlah entities.
Use Case:
Di gunakan sebagai tempat menuliskannya flow atau alur bisnis logika.
Interface Adapter (Repository dan Handler)
Mediator atau penghubung antara layer framework dengan layer use case.
Frameworks (Database dan HTTP server)
Level paling luar merupakan bagian yang berhubungan dengan framework.


Kriteria Opsional Forum API
Selain kriteria utama, terdapat kriteria opsional yang yang dapat Anda penuhi agar mendapat nilai yang baik.

Menambahkan Balasan pada Komentar Thread
API harus dapat menambahkan balasan pada komentar thread melalui route:

Method: POST
Path: /threads/{threadId}/comments/{commentId}/replies
Body Request:
{
    "content": string
}
Response yang harus dikembalikan:

Status Code: 201
Response Body:
{
    "status": "success",
    "data": {
        "addedReply": {
            "id": "reply-BErOXUSefjwWGW1Z10Ihk",
            "content": "sebuah balasan",
            "owner": "user-CrkY5iAgOdMqv36bIvys2"
        }
    }
}
Ketentuan:

Menambahkan balasan pada komentar thread merupakan resource yang dibatasi (restrict). Untuk mengaksesnya membutuhkan access token guna mengetahui siapa yang membuat balasan komentar.
Jika thread atau komentar yang diberi balasan tidak ada atau tidak valid, maka:
Kembalikan dengan status code 404; serta
Berikan body response: 
status: “fail”
message: Pesan apapun selama tidak kosong.
Jika properti body request tidak lengkap atau tidak sesuai, maka:
Kembalikan dengan status code 400; serta
Berikan body response: 
status: “fail”
message: Pesan apapun selama tidak kosong.
Balasan pada komentar thread harus ditampilkan pada setiap item comments ketika mengakses detail thread. Contohnya seperti ini:
{
    "status": "success",
    "data": {
        "thread": {
            "id": "thread-AqVg2b9JyQXR6wSQ2TmH4",
            "title": "sebuah thread",
            "body": "sebuah body thread",
            "date": "2021-08-08T07:59:16.198Z",
            "username": "dicoding",
            "comments": [
                {
                    "id": "comment-q_0uToswNf6i24RDYZJI3",
                    "username": "dicoding",
                    "date": "2021-08-08T07:59:18.982Z",
                    "replies": [
                        {
                            "id": "reply-BErOXUSefjwWGW1Z10Ihk",
                            "content": "**balasan telah dihapus**",
                            "date": "2021-08-08T07:59:48.766Z",
                            "username": "johndoe"
                        },
                        {
                            "id": "reply-xNBtm9HPR-492AeiimpfN",
                            "content": "sebuah balasan",
                            "date": "2021-08-08T08:07:01.522Z",
                            "username": "dicoding"
                        }
                    ],
                    "content": "sebuah comment"
                }
            ]
        }
    }
}
Balasan yang dihapus ditampilkan dengan konten **balasan telah dihapus**.
Balasan diurutkan secara ascending (dari kecil ke besar) berdasarkan waktu berkomentar.


Menghapus Balasan pada Komentar Thread
API harus dapat menghapus balasan pada komentar thread melalui route:

Method: DELETE
Path: /threads/{threadId}/comments/{commentId}/replies/{replyId}
Response yang harus dikembalikan:

Status Code: 200
Response Body:
{
    "status": "success"
}
Ketentuan:

Menghapus balasan pada komentar thread merupakan resource yang dibatasi (restrict). Untuk mengaksesnya membutuhkan access token guna mengetahui siapa yang menghapus balasan.
Hanya pemilik balasan yang dapat menghapus balasan. Bila bukan pemilik balasan, maka:
Kembalikan dengan status code 403; serta
Berikan body response: 
status: “fail”
message: Pesan apapun selama tidak kosong.
Jika thread, komentar, atau balasan yang hendak dihapus tidak ada atau tidak valid, maka:
Kembalikan dengan status code 404; serta
Berikan body response: 
status: “fail”
message: Pesan apapun selama tidak kosong.
Balasan dihapus secara soft delete, alias tidak benar-benar dihapus dari database. Anda bisa membuat dan memanfaatkan kolom seperti is_delete sebagai indikator apakah komentar dihapus atau tidak.


Pengujian API
Ketika membangun Forum API, tentu Anda perlu menguji untuk memastikan API berjalan sesuai dengan kriteria yang ada. Kami sudah menyediakan berkas Postman Collection dan Environment yang dapat Anda gunakan untuk pengujian. Silakan unduh berkasnya pada tautan berikut:

Forum API V1 Postman Collection + Environment Test.


Cara Import Collection dan Environment Forum API
Silakan unduh tautan yang diberikan di atas.
Ekstrak berkas yang sudah diunduh hingga menghasilkan dua berkas file JSON.
Kemudian import kedua berkas tersebut pada Postman. Caranya, buka aplikasi Postman, klik tombol Import yang berada di atas panel kiri aplikasi Postman.
Kemudian klik tombol Upload Files untuk meng-import kedua berkas JSON hasil ekstraksi.
Pilih kedua berkas JSON hasil ekstraksi dan klik tombol Open.
Kemudian klik Import.
Setelah itu, Forum API V1 Collection dan Environment akan tersedia pada Postman Anda.
Jangan lupa untuk gunakan Environment yang sudah diimpor.


Tips Menjalankan Pengujian Forum API
Pastikan Anda selalu menjalankan pengujian secara berurutan. Karena beberapa request membutuhkan nilai yang didapat dari request sebelumnya. Contoh, pengujian pada folder Authentications membutuhkan folder Users untuk dijalankan. Karena untuk mendapatkan melakukan autentikasi, tentu harus ada data pengguna di database.
Untuk menjalankan request secara berurutan sekaligus, Anda bisa memanfaatkan fitur Collection Runner.
Kerjakanlah proyek fitur demi fitur, agar Anda mudah dalam menjalankan pengujiannya.
Jika merasa seluruh fitur yang dibangun sudah benar namun pengujiannya selalu gagal, kemungkinan database Anda kotor dengan data pengujian yang Anda lakukan sebelum-sebelumnya, dan itu bisa menjadi salah satu penyebab pengujian selalu gagal. Solusinya, silakan hapus seluruh data (truncate) pada tabel melalui psql.


Kriteria Penilaian Submission
Submission Anda akan dinilai oleh Reviewer guna menentukan kebenaran submission yang Anda kerjakan. Agar dapat melanjutkan pembelajaran, proyek Forum API harus memenuhi seluruh pengujian otomatis pada seluruh Postman Request, terkecuali request yang bertanda [optional]. Bila salah satu pengujiannya gagal, maka proyek Anda akan kami tolak.

Submission Anda akan dinilai oleh Reviewer dengan skala 1-5. Untuk mendapatkan nilai tinggi, Anda bisa menerapkan beberapa saran berikut:

Menyelesaikan kriteria opsional, yakni fitur balasan komentar thread.
Menerapkan functional test (server test) untuk resource thread dan comment.
Menerapkan 100% Test Coverage.
Menuliskan kode dengan bersih alias mematuhi style guide yang Anda tetapkan.
Berikut adalah detail penilaian submission:

Bintang 1 : Semua ketentuan wajib terpenuhi, namun terdapat indikasi kecurangan dalam mengerjakan submission.
Bintang 2 : Semua ketentuan wajib terpenuhi, namun terdapat kekurangan pada penulisan kode. Seperti tidak menerapkan modularization atau gaya penulisan tidak konsisten.
Bintang 3 : Semua ketentuan wajib terpenuhi, namun tidak terdapat improvisasi atau persyaratan opsional yang dipenuhi.
Bintang 4 : Semua ketentuan wajib terpenuhi dan menerapkan minimal dua saran di atas.
Bintang 5 : Semua ketentuan wajib terpenuhi dan menerapkan seluruh saran di atas.
Catatan:
Jika submission Anda ditolak maka tidak ada penilaian. Kriteria penilaian bintang di atas hanya berlaku jika submission Anda lulus.


Ketentuan Berkas Submission
Berkas submission yang dikirim merupakan folder proyek dari Forum API dalam bentuk ZIP. 
Pastikan di dalam folder proyek yang Anda kirim terdapat berkas package.json.
Untuk menjaga kredensial Anda, diperbolehkan untuk tidak melampirkan berkas .env selama penamaan variable environment sesuai dengan starter proyek yang kami sediakan. 
Pastikan Anda hapus dulu berkas node_modules pada folder proyek sebelum mengkompresi dalam bentuk ZIP.

Submission Anda akan Ditolak bila
Kriteria wajib Forum API tidak terpenuhi.
Ketentuan berkas submission tidak terpenuhi.
Proyek yang Anda kirim tidak dapat dijalankan dengan baik (Reviewer menggunakan Node.js versi LTS v22).
Menggunakan database selain PostgreSQL.
Menggunakan bahasa pemrograman dan teknologi lain, selain JavaScript atau TypeScript dan Node.js.
Menggunakan Framework Node.js selain Express.
Melakukan kecurangan seperti tindakan plagiasi.


Forum Diskusi
Jika mengalami kesulitan, Anda bisa menanyakan langsung ke forum diskusi. https://www.dicoding.com/academies/276/discussions.


----

Tips Dalam Mengerjakan Submission
Ketika mengerjakan proyek submission mungkin Anda mengalami kendala. Oleh karena itu kami telah mengumpulkan beberapa kendala yang sebelumnya sering ditemui oleh siswa-siswa lain. Agar kendala tersebut tidak terulang kepada Anda, maka kami telah membuat kumpulan tips untuk menanggulanginya.   

Berikut adalah beberapa tips yang dapat Anda gunakan sebagai bantuan dalam pembuatan submission.

Jangan gunakan expected value sebagai nilai kembalian fungsi yang di-mock
Ketika melakukan testing, jangan gunakan expected value sebagai nilai kembalian fungsi yang di-mock. Contohnya seperti ini:
GetPreparedEngineUseCase.test.js
GetPreparedEngineUseCase.js
it('should fill fuel engine to 100 and start engine', function () {
    const expectedEngine = {
        name: 'engine1',
        fuel: 100,
        start: true
    };
        
    const mockEngineRepository = {}
    mockEngineRepository.getEngine = vi.fn(() => expectedEngine);
        
    const getPreparedEngineUseCase = new GetPreparedEngineUseCase(mockEngineRepository);
        
    console.log(expectedEngine)
    const engine = getPreparedEngineUseCase.execute()
    console.log(expectedEngine)
        
        
    expect(engine).toStrictEqual(expectedEngine)
});
Kode di atas akan menghasilkan output dari kedua  console.log()  (pada kode testing) menjadi seperti berikut: 

Output pertama sebelum fungsi getPreparedEngineUseCase.execute()dijalankan:
{
   name: 'engine1', 
   fuel: 100, 
   start: true
}
Output kedua setelah fungsi getPreparedEngineUseCase.execute()dijalankan:
{    
   name: 'engine1', 
   fuel: 50, 
   start: false
}
Bisa dilihat bahwa variable expectedEngine di atas berubah nilainya.

Jika diperhatikan lagi, kode use case di atas juga masih tidak sesuai dengan spesifikasi testing yang dibuat. Pada spesifikasi testing, dituliskan 'should fill fuel engine to 100 and start engine'. Tetapi nilai expectedEngine malah berubah menjadi fuel: 50 dan start: false.

Walaupun testing masih belum sesuai, namun ia akan tetap berhasil karena expectedEngine dijadikan nilai kembalian fungsi yang di-mock.

Oleh karena itu, kode testing yang benar seharusnya seperti ini:

GetPreparedEngineUseCase.test.js
 it('should fill fuel engine to 100 and should start engine', function () {
    const expectedEngine = {
        name: 'engine1',
        fuel: 100,
        start: true
    };
    
    const engineRepository = {}
    engineRepository.getEngine = vi.fn(() => ({
        name: 'engine1',
        fuel: 0,
        start: false
    }));
 
    const getPreparedEngineUseCase = new GetPreparedEngineUseCase(engineRepository);
    
    console.log(expectedEngine)
    const engine = getPreparedEngineUseCase.execute()
    console.log(expectedEngine)
    
    expect(engine).toStrictEqual(expectedEngine)
});
Nilai kembalian pada fungsi yang di-mock bersifat netral dan biasanya berbeda dengan expected result. Ketika test di atas dijalankan maka akan terjadi error seperti ini.
Error: expect(received).toStrictEqual(expected) // deep equality
 
- Expected  - 2
+ Received  + 2
 
Object {
-   "fuel": 100,
+   "fuel": 50,
    "name": "engine1",
    "start": true,
+   "start": false,
}      
Hal ini wajar karena kode pada use case yang dibuat memang masih salah dan dengan ini kita tahu bahwa ada bug yang terjadi pada kode yang kita buat. Jadi, kita bisa memperbaiki bug yang terjadi pada use case tersebut. Inilah salah satu kegunaan testing, yaitu mendeteksi bug sedini mungkin.

Kode use case yang benar adalah seperti berikut
GetPreparedEngineUseCase.js
class GetPreparedEngineUseCase {
    constructor(engineRepository) {
        this.engineRepository = engineRepository;
    }
 
    execute() {
        let engine = this.engineRepository.getEngine();
 
        engine.fuel = 100
        engine.start = true
 
        return engine
    }
}
Saat testing pastikan verifikasi semua fungsi yang di-mock
Ketika melakukan mock pada sebuah fungsi, pastikan fungsi tersebut sudah diverifikasi bahwa memang benar-benar dipanggil. Karena jika tidak, maka bisa saja kode yang di-test tersebut menjadi tidak valid. Contohnya seperti ini:

AddEngineUseCase.test.js
AddEngineUseCase.js
it('should return the engine properly', async () => {
    const expectedEngine = {
        name: 'Faster Speed 3000',
        manufacture: 'Faster Speed Inc',
        maxFuel: 200,
    }
 
    const engineRepository = {}
    const manufacturerRepository = {}
 
    const getEngineUseCase = new GetEngineUseCase(engineRepository, manufacturerRepository);
 
    engineRepository.add = vi.fn(() => Promise.resolve())
    manufacturerRepository.verifyManufactureIsRegistered = vi.fn(()=>Promise.resolve())
 
    const engine = await getEngineUseCase.execute('Faster Speed 3000', 'Faster Speed Inc', 200);
 
    expect(engine).toStrictEqual(expectedEngine)
});
Test di atas akan berjalan dengan baik, tetapi jika suatu saat ada developer lain yang mengubah kode use casenya sebenarnya akan ada masalah yang muncul. Misal ada developer lain yang mengapus semua pemanggilan fungsi repository dari kode di atas, menjadi seperti ini:

AddEngineUseCase.js
class AddEngineUseCase {
    constructor(engineRepository, manufacturerRepository) {
        this.engineRepository = engineRepository;
        this.manufacturerRepository = manufacturerRepository;
    }
 
    async execute(name, manufacture, maxFuel) {
        // kode dihapus
        // kode dihapus
 
        return {
            name,
            manufacture,
            maxFuel
        }
    }
}
Maka test tetap lolos meskipun ada kode penting yang dihapus. Dampaknya jika program tersebut dijalankan di production akan terjadi error atau anomali yang susah ditelusuri. 

Agar test tersebut dapat menjadi ‘safety net’ bagi developer lain, maka wajib memverifikasi setiap fungsi yang di-mock, contohnya seperti ini: 

AddEngineUseCase.test.js
it('should return the engine properly', async () => {
    const expectedEngine = {
        name: 'Faster Speed 3000',
        manufacture: 'Faster Speed Inc',
        maxFuel: 200,
    }
 
    const engineRepository = {}
    const manufacturerRepository = {}
 
    const getEngineUseCase = new GetEngineUseCase(engineRepository, manufacturerRepository)
 
    engineRepository.add = vi.fn(() => Promise.resolve())
    manufacturerRepository.verifyManufactureIsRegistered = vi.fn(() => Promise.resolve())
 
    const engine = await getEngineUseCase.execute('Faster Speed 3000', 'Faster Speed Inc', 200)
 
    expect(engine).toStrictEqual(expectedEngine)
    expect(engineRepository.add).toHaveBeenCalledWith('Faster Speed 3000', 'Faster Speed Inc', 200)
    expect(manufacturerRepository.verifyManufactureIsRegistered).toHaveBeenCalledWith('Faster Speed Inc')
});
Anda tidak hanya bisa menggunakan fungsi toHaveBeenCalledWith(), tapi bisa juga menggunakan fungsi toBeCalled(), toBeCalledTimes(), dan yang lainnya.


Perlu diingat kembali bahwa use case atau entity-lah yang menjadi tempat logic disimpan
Kode di bawah memiliki business logic yang disimpan di repository dan hal ini tidak bagus karena menurut Clean Architecture, logika bisnis hanya boleh didefinisikan di dalam domain atau use case. Perhatikan kode berikut:

EngineRepository.js
GetEngineUseCase.js
class EngineRepository {
   constructor(pool) {
       this.pool = pool;
   }
 
   async getEngines() {
       const result = await this.pool.query('SELECT * FROM engine')
 
       const engine = result.row[0]
 
       if (engine.speed > 1000) {
           engine.type = 'Super Engine'
       } else if (engine.speed > 500) {
           engine.type = 'Moderate Engine'
       } else {
           engine.type = 'Light Engine'
       }
 
       return engine
   }
 
}
Jika kita menerapkan Clean Architecture maka kode yang benar untuk contoh kasus di atas adalah seperti ini: 

EngineRepository.js
GetEngineUseCase.js
class EngineRepository {
    constructor(pool) {
        this.pool = pool;
    }
 
    async getEngines() {
        const result = await this.pool.query('SELECT * FROM engine')
 
        const engine = result.row[0]
        
        return engine
    }
    
}


Ketika melakukan integration test yang bersifat perubahan (insert, update, atau delete), pastikan database atau external agency lainnya juga berubah
Kode di bawah ini adalah kode yang tidak menerapkan testing terhadap external agency. Perhatikanlah contoh berikut:

EngineRepository.test.js
describe('AddEngineRepositoryTest', () => {
    it('should return added engine correctly ', function () {
        const engine  = {
            name: 'Faster Speed 3000',
            manufacture: 'Faster Speed Inc',
            maxFuel: 200,
        }
 
        const engineRepository = new EngineRepository();
        const addedEngine = engineRepository.add(engine);
        expect(addedEngine).toStrictEqual(engine);
    });
})
Test di atas sebenarnya sudah hampir benar, tetapi karena ini merupakan integration test, maka Anda juga perlu menguji external agency-nya pada kasus ini external agency-nya adalah database. Sehingga test yang benar adalah seperti ini:

EngineRepository.test.js
EnginesTableTestHelper.js
describe('AddEngineRepositoryTest', () => {
    it('should return added engine correctly ', function () {
        const engine  = {
            name: 'Faster Speed 3000',
            manufacture: 'Faster Speed Inc',
            maxFuel: 200,
        }
 
        const engineRepository = new EngineRepository();
        const addedEngine = engineRepository.add(engine);
        expect(addedEngine).toStrictEqual(engine);
    });
 
    it('should persist add engine', function () {
        const enginePayload  = {
            name: 'Faster Speed 3000',
            manufacture: 'Faster Speed Inc',
            maxFuel: 200,
        }
 
        const engineRepository = new EngineRepository();
        engineRepository.add(enginePayload);
 
        const engine = EnginesTableTestHelper.findEngineByName('Faster Speed 3000')
        expect(engine).toHaveLength(1)
    });
})
Pada test di atas kita membuat object baru bernama EnginesTableTestHelper yang berfungsi untuk membantu jalannya testing. Dengan fungsi yang ada di dalam object tersebut, kita bisa mengambil data yang ada di dalam database dan menggunakan data tersebut sebagai validasi testing.

Lakukan autentikasi di level interface
Jika sewaktu-waktu aplikasi back-end yang kita buat ini menjadi aplikasi lain, contohnya aplikasi terminal/cmd  (CLI), maka apabila autentikasi berada pada level use case, use case tersebut jadi tidak bisa digunakan kembali karena bisa saja cara autentikasinya berbeda. Contoh kode autentikasi yang benar adalah seperti berikut

handler.js
AddEngineUseCase.js
addEngineHandler(request){
   const { id: userId } = request.auth.credentials
 
   AddEngineUseCase.execute(userId, request.payload)
}

---

